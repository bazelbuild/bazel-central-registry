# Kokoro Configuration and Build script

As part of the software supply chain security efforts, the automation team runs
a Kokoro job to capture the commit hash of each release. The script and
configuration for this Kokoro job live in this directory.
